import io
import os
from pathlib import Path
import tempfile
import unittest
import zipfile

os.environ.setdefault('OWNER_PASSWORD', 'offline-testing-password-secret-123')
os.environ.setdefault('DEV_ALLOW_HTTP', '1')
from app import app, make_archives, media_kind, want_media

class OfflineTest(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_health(self):
        self.assertEqual(self.client.get('/health').json['status'], 'ok')

    def test_private_routes(self):
        for url in ('/', '/status', '/archive/01_history_text.zip'):
            result = self.client.get(url)
            self.assertEqual(result.status_code, 302)
            self.assertIn('/login', result.location)

    def test_csrf(self):
        self.assertEqual(self.client.post('/login', data={'password':'bad'}).status_code, 403)

    def test_valid_owner(self):
        self.client.get('/login')
        with self.client.session_transaction() as s:
            token = s['csrf']
        r = self.client.post('/login', data={'csrf':token, 'password':os.environ['OWNER_PASSWORD']})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.client.get('/').status_code, 200)

    def test_archives(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            (base/'media').mkdir()
            for name in ('history.json','history.txt','manifest.json','README.txt'):
                (base/name).write_text('test',encoding='utf8')
            (base/'media'/'1.ogg').write_bytes(b'123')
            files = make_archives(base)
            self.assertEqual(len(files),2)
            with zipfile.ZipFile(base/files[0]) as f:
                self.assertIn('history.json',f.namelist())
            with zipfile.ZipFile(base/files[1]) as f:
                self.assertIn('media/1.ogg',f.namelist())

    def test_media_modes(self):
        self.assertTrue(want_media('voice','photos_voice'))
        self.assertTrue(want_media('photo','photos_voice'))
        self.assertFalse(want_media('video','photos_voice'))
        self.assertTrue(want_media('video','all'))
        self.assertFalse(want_media(None,'all'))

if __name__ == '__main__':
    unittest.main()
