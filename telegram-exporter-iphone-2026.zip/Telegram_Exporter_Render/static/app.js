const statusEl = document.getElementById('progress');
if (statusEl && statusEl.dataset.active === '1') {
  const poll = async () => {
    try {
      const response = await fetch('/status', { credentials: 'same-origin', cache: 'no-store' });
      if (!response.ok) return;
      const data = await response.json();
      if (data.state === 'running') {
        statusEl.textContent = `Выполняется: ${data.messages} сообщений, ${data.media} медиа`;
        setTimeout(poll, 2500);
      } else {
        location.reload();
      }
    } catch (error) {
      statusEl.textContent = 'Нет связи с сервером. Обновите страницу вручную.';
    }
  };
  setTimeout(poll, 2500);
}
