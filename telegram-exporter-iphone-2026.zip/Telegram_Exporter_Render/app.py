"""Owner-only Telegram private-chat exporter for an ephemeral web host.

Designed for a single owner and a single gunicorn process. Do not run multiple
workers or publicly expose it without OWNER_PASSWORD.
"""
from __future__ import annotations

import asyncio
from collections import defaultdict, deque
from datetime import datetime, timezone
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import tempfile
import threading
import time
import zipfile
from functools import wraps
from typing import Any

from flask import Flask, abort, flash, jsonify, redirect, render_template, request, send_file, session, url_for
from telethon import TelegramClient, errors

BASE = Path(os.environ.get("EXPORT_DATA_DIR", tempfile.gettempdir())) / "owner_telegram_exporter"
BASE.mkdir(mode=0o700, parents=True, exist_ok=True)
SESSION_PATH = BASE / "private_telegram_user"
EXPORT_BASE = BASE / "exports"
EXPORT_BASE.mkdir(mode=0o700, parents=True, exist_ok=True)
MAX_ARCHIVE_BYTES = 35 * 1024 * 1024

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("APP_SESSION_SECRET") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=os.environ.get("DEV_ALLOW_HTTP") != "1",
    SESSION_COOKIE_SAMESITE="Strict",
    PERMANENT_SESSION_LIFETIME=3600,
    MAX_CONTENT_LENGTH=65536,
)
OWNER_PASSWORD = os.environ.get("OWNER_PASSWORD", "")
if OWNER_PASSWORD and len(OWNER_PASSWORD) < 20:
    raise RuntimeError("OWNER_PASSWORD must be at least 20 characters long")

lock = threading.RLock()
state: dict[str, Any] = {
    "api_id": None, "api_hash": None, "phone": None, "phone_hash": None,
    "signed_in": False, "awaiting_2fa": False, "dialogs": [],
    "job_state": "idle", "processed": 0, "downloaded": 0,
    "job_error": None, "job_title": None, "archives": [], "job_path": None,
}
failed_logins: dict[str, deque[float]] = defaultdict(deque)


def update(**kwargs):
    with lock:
        state.update(kwargs)


def get_state(*keys):
    with lock:
        return tuple(state[k] for k in keys)


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def require_csrf():
    if request.method == "POST":
        expected = session.get("csrf")
        provided = request.form.get("csrf", "")
        if not expected or not hmac.compare_digest(expected, provided):
            abort(403)


def owner_only(fn):
    @wraps(fn)
    def guarded(*args, **kwargs):
        if not session.get("owner_ok"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return guarded


def login_rate_limit(ip: str) -> bool:
    now = time.monotonic()
    q = failed_logins[ip]
    while q and now - q[0] > 900:
        q.popleft()
    return len(q) >= 5


def make_client():
    api_id, api_hash = get_state("api_id", "api_hash")
    if not api_id or not api_hash:
        raise RuntimeError("Сначала укажите ключи Telegram API.")
    return TelegramClient(str(SESSION_PATH), api_id, api_hash,
                          request_retries=2, connection_retries=2, retry_delay=2)


async def start_login(phone):
    client = make_client()
    await client.connect()
    try:
        sent = await client.send_code_request(phone)
        return sent.phone_code_hash
    finally:
        await client.disconnect()


async def complete_login(code: str | None = None, password: str | None = None):
    client = make_client()
    await client.connect()
    try:
        if password is not None:
            await client.sign_in(password=password)
        else:
            phone, phone_hash = get_state("phone", "phone_hash")
            await client.sign_in(phone=phone, code=code, phone_code_hash=phone_hash)
        return await client.is_user_authorized()
    finally:
        await client.disconnect()


async def list_private_chats():
    client = make_client()
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise RuntimeError("Telegram-сессия не авторизована")
        rows = []
        async for d in client.iter_dialogs():
            if d.is_user and not getattr(d.entity, "bot", False) and not getattr(d.entity, "is_self", False):
                rows.append({"id": d.id, "name": d.name or f"Контакт {d.id}"})
            if len(rows) >= 2000:
                break
        return rows
    finally:
        await client.disconnect()


def media_kind(msg):
    if getattr(msg, "photo", None): return "photo"
    if getattr(msg, "voice", None): return "voice"
    if getattr(msg, "video_note", None): return "video_note"
    if getattr(msg, "video", None): return "video"
    if getattr(msg, "audio", None): return "audio"
    if getattr(msg, "sticker", None): return "sticker"
    if getattr(msg, "document", None): return "document"
    return "other" if getattr(msg, "media", None) else None


def want_media(kind, mode):
    return kind is not None and (mode == "all" or mode == "photos_voice" and kind in ("photo", "voice"))


def make_archives(folder: Path):
    archives = []
    textzip = folder / "01_history_text.zip"
    with zipfile.ZipFile(textzip, "w", zipfile.ZIP_DEFLATED) as z:
        for name in ("history.json", "history.txt", "manifest.json", "README.txt"):
            z.write(folder / name, arcname=name)
    archives.append(textzip.name)
    mediafiles = sorted((folder / "media").rglob("*")) if (folder / "media").exists() else []
    mediafiles = [x for x in mediafiles if x.is_file()]
    archive = None
    size = 0
    idx = 1
    try:
        for file in mediafiles:
            data_size = file.stat().st_size
            if archive is None or (size and size + data_size > MAX_ARCHIVE_BYTES):
                if archive:
                    archive.close()
                idx += 1
                name = f"{idx:02d}_media.zip"
                archive = zipfile.ZipFile(folder / name, "w", zipfile.ZIP_STORED)
                archives.append(name)
                size = 0
            archive.write(file, arcname=str(file.relative_to(folder)))
            size += data_size
    finally:
        if archive:
            archive.close()
    return archives


def safe_error(exc):
    # Only error class is exposed; Telegram RPC messages may contain identifiers.
    return type(exc).__name__


async def export_async(dialog_id: int, mode: str, folder: Path, title: str):
    client = make_client()
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise RuntimeError("Сессия Telegram закончилась: авторизуйтесь снова.")
        selected = None
        async for dialog in client.iter_dialogs():
            if dialog.id == dialog_id and dialog.is_user and not getattr(dialog.entity, "bot", False):
                selected = dialog.entity
                break
        if selected is None:
            raise RuntimeError("Выбранный личный чат недоступен.")
        me = await client.get_me()
        folder.mkdir(mode=0o700, parents=True, exist_ok=False)
        (folder / "media").mkdir(mode=0o700)
        count, downloaded = 0, 0
        json_path = folder / "history.json"
        text_path = folder / "history.txt"
        with json_path.open("w", encoding="utf-8") as jf, text_path.open("w", encoding="utf-8") as tf:
            jf.write('{"format_version":1,"messages":[\n')
            async for msg in client.iter_messages(selected, reverse=True):
                kind = media_kind(msg)
                rel_path = None
                media_error = None
                if want_media(kind, mode):
                    try:
                        # File size cap per item guards ephemeral storage & huge videos.
                        file_size = getattr(getattr(msg, "file", None), "size", 0) or 0
                        if file_size > 90 * 1024 * 1024:
                            media_error = "file_too_large_90MB"
                        else:
                            path = await client.download_media(msg, file=str(folder / "media" / f"{msg.id}"))
                            if path:
                                p = Path(path).resolve()
                                if p.is_relative_to((folder / "media").resolve()) and p.is_file():
                                    rel_path = str(p.relative_to(folder))
                                    downloaded += 1
                    except Exception as exc:
                        media_error = safe_error(exc)
                date = msg.date.astimezone(timezone.utc).isoformat() if msg.date else None
                sender_id = msg.sender_id
                sender_name = "Я" if msg.out else title
                record = {
                    "id": msg.id, "date_utc": date, "from_me": bool(msg.out),
                    "sender_id": sender_id, "sender_name": sender_name,
                    "reply_to_msg_id": getattr(msg, "reply_to_msg_id", None),
                    "forwarded": bool(getattr(msg, "fwd_from", None)),
                    "text": msg.raw_text or "", "media_type": kind,
                    "media_path": rel_path, "media_error": media_error,
                }
                if count:
                    jf.write(",\n")
                jf.write(json.dumps(record, ensure_ascii=False))
                head = f"[{date}] {sender_name} (id={msg.id})"
                if record["reply_to_msg_id"] is not None:
                    head += f" [ответ на #{record['reply_to_msg_id']}]"
                tf.write(head + "\n" + (record["text"] or "") + "\n")
                if kind:
                    tf.write(f"[Медиа: {kind}; путь: {rel_path or 'не скачано'}]\n")
                tf.write("\n")
                count += 1
                if count % 10 == 0:
                    update(processed=count, downloaded=downloaded)
            jf.write('\n]}\n')
        manifest = {"chat_name": title, "chat_id": dialog_id, "exported_utc": datetime.now(timezone.utc).isoformat(),
                    "message_count": count, "downloaded_media": downloaded, "mode": mode}
        (folder / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        (folder / "README.txt").write_text("Содержимое доступно только владельцу. История сообщений хранит личные данные собеседников.\n", encoding="utf-8")
        zips = make_archives(folder)
        update(processed=count, downloaded=downloaded)
        return zips
    finally:
        await client.disconnect()


def export_job(dialog_id, mode, title):
    folder = EXPORT_BASE / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + secrets.token_hex(5))
    try:
        zips = asyncio.run(export_async(dialog_id, mode, folder, title))
        update(job_state="done", archives=zips, job_path=str(folder), job_error=None)
    except Exception as exc:
        shutil.rmtree(folder, ignore_errors=True)
        update(job_state="error", job_error=safe_error(exc), archives=[], job_path=None)


def reset_local():
    with lock:
        if state["job_state"] == "running":
            raise RuntimeError("Экспорт выполняется. Дождитесь завершения.")
    for f in BASE.glob("private_telegram_user.session*"):
        if f.is_file():
            f.unlink(missing_ok=True)
    shutil.rmtree(EXPORT_BASE, ignore_errors=True)
    EXPORT_BASE.mkdir(mode=0o700, parents=True, exist_ok=True)
    update(api_id=None, api_hash=None, phone=None, phone_hash=None,
           signed_in=False, awaiting_2fa=False, dialogs=[], job_state="idle",
           processed=0, downloaded=0, archives=[], job_path=None,
           job_title=None, job_error=None)


@app.get("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/login", methods=["GET", "POST"])
def login():
    if not OWNER_PASSWORD:
        return render_template("login.html", configured=False), 503
    if session.get("owner_ok"):
        return redirect(url_for("home"))
    if request.method == "POST":
        ip = request.remote_addr or "unknown"
        if login_rate_limit(ip):
            flash("Слишком много попыток. Повторите позже.", "error")
        elif hmac.compare_digest(request.form.get("password", ""), OWNER_PASSWORD):
            session.clear()
            session["owner_ok"] = True
            session["csrf"] = secrets.token_urlsafe(32)
            session.permanent = True
            return redirect(url_for("home"))
        else:
            failed_logins[ip].append(time.monotonic())
            flash("Неверный пароль.", "error")
    return render_template("login.html", configured=True)


@app.get("/")
@owner_only
def home():
    signed_in, dialogs, job_state, job_error, archives, job_title, processed, downloaded = get_state(
        "signed_in", "dialogs", "job_state", "job_error", "archives", "job_title", "processed", "downloaded")
    return render_template("index.html", signed_in=signed_in, dialogs=dialogs,
                           job_state=job_state, job_error=job_error, archives=archives,
                           job_title=job_title, processed=processed, downloaded=downloaded,
                           api_ready=bool(get_state("api_id")[0]), waiting_password=get_state("awaiting_2fa")[0])


@app.post("/telegram/start")
@owner_only
def telegram_start():
    if get_state("job_state")[0] == "running": abort(409)
    phone = request.form.get("phone", "").strip()
    api_id = request.form.get("api_id", "").strip()
    api_hash = request.form.get("api_hash", "").strip()
    if not re.fullmatch(r"\+?[1-9]\d{7,14}", phone) or not api_id.isdecimal() or not re.fullmatch(r"[a-fA-F0-9]{32}", api_hash):
        flash("Проверьте телефон, API ID и API Hash.", "error")
        return redirect(url_for("home"))
    reset_local()
    update(phone=phone, api_id=int(api_id), api_hash=api_hash, awaiting_2fa=False)
    try:
        code_hash = asyncio.run(start_login(phone))
        update(phone_hash=code_hash)
        flash("Код Telegram отправлен. Введите его ниже.", "success")
    except Exception as exc:
        flash("Ошибка отправки кода Telegram: " + safe_error(exc), "error")
    return redirect(url_for("home"))


@app.post("/telegram/verify")
@owner_only
def telegram_verify():
    if not get_state("phone_hash")[0]: abort(409)
    code = request.form.get("code", "").replace(" ", "")
    try:
        ok = asyncio.run(complete_login(code=code))
        if ok:
            update(signed_in=True, awaiting_2fa=False, phone_hash=None)
            flash("Telegram подключён.", "success")
    except errors.SessionPasswordNeededError:
        update(awaiting_2fa=True)
        flash("Введите пароль двухэтапной проверки Telegram.", "success")
    except Exception as exc:
        flash("Ошибка входа: " + safe_error(exc), "error")
    return redirect(url_for("home"))


@app.post("/telegram/2fa")
@owner_only
def telegram_twofa():
    if not get_state("awaiting_2fa")[0]: abort(409)
    try:
        if asyncio.run(complete_login(password=request.form.get("password", ""))):
            update(signed_in=True, awaiting_2fa=False, phone_hash=None)
            flash("Telegram подключён.", "success")
    except Exception as exc:
        flash("Ошибка двухэтапной проверки: " + safe_error(exc), "error")
    return redirect(url_for("home"))


@app.post("/telegram/chats")
@owner_only
def telegram_chats():
    if not get_state("signed_in")[0]: abort(409)
    try:
        dialogs = asyncio.run(list_private_chats())
        update(dialogs=dialogs)
        flash(f"Личных чатов найдено: {len(dialogs)}", "success")
    except Exception as exc:
        flash("Ошибка загрузки чатов: " + safe_error(exc), "error")
    return redirect(url_for("home"))


@app.post("/telegram/export")
@owner_only
def telegram_export():
    selected = request.form.get("dialog_id", "")
    mode = request.form.get("mode", "photos_voice")
    confirmed = request.form.get("confirmed") == "yes"
    if mode not in ("text", "photos_voice", "all") or not confirmed:
        abort(400)
    with lock:
        matches = [d for d in state["dialogs"] if str(d["id"]) == selected]
        if not matches or not state["signed_in"] or state["job_state"] == "running":
            abort(409)
        title = matches[0]["name"]
        state.update(job_state="running", processed=0, downloaded=0, archives=[], job_error=None, job_title=title)
    threading.Thread(target=export_job, args=(int(selected), mode, title), daemon=True).start()
    flash("Экспорт запущен. Не закрывайте страницу слишком надолго.", "success")
    return redirect(url_for("home"))


@app.get("/status")
@owner_only
def status():
    job_state, processed, downloaded, job_error = get_state("job_state", "processed", "downloaded", "job_error")
    return jsonify({"state": job_state, "messages": processed, "media": downloaded, "error": job_error})


@app.get("/archive/<name>")
@owner_only
def archive(name):
    job_state, path, archive_names = get_state("job_state", "job_path", "archives")
    if job_state != "done" or not path or name not in archive_names:
        abort(404)
    file = (Path(path) / name).resolve()
    if file.parent != Path(path).resolve() or not file.is_file():
        abort(404)
    return send_file(file, as_attachment=True, download_name=name,
                     mimetype="application/zip", max_age=0)


@app.post("/reset")
@owner_only
def reset():
    try:
        reset_local()
        flash("Данные, архивы и локальная Telegram-сессия удалены с сервера.", "success")
    except RuntimeError as exc:
        flash(str(exc), "error")
    return redirect(url_for("home"))


@app.post("/logout")
@owner_only
def logout():
    if get_state("job_state")[0] == "running":
        flash("Дождитесь окончания экспорта перед выходом.", "error")
        return redirect(url_for("home"))
    reset_local()
    session.clear()
    return redirect(url_for("login"))


@app.after_request
def security_headers(response):
    response.headers.update({
        "Cache-Control": "no-store", "Pragma": "no-cache",
        "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": "default-src 'self'; style-src 'self'; script-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",
    })
    return response


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
